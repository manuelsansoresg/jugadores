<?php $__env->startSection('titulo', $registro->exists ? 'Editar categoría' : 'Agregar categoría'); ?>
<?php $__env->startSection('contenido'); ?>

<section class="tarjeta formulario">
    <form method="POST" action="<?php echo e(route('categorias.save', $registro->id)); ?>" enctype="multipart/form-data">
        
        <?php echo csrf_field(); ?>
        <div class="campo">
            <label for="nombre">Nombre</label>
            <input id="nombre" name="nombre" value="<?php echo e(old('nombre', $registro->nombre)); ?>" maxlength="100" required>
        </div>
        
        <div class="acciones-formulario">
            <button class="boton" type="submit" name="accion" value="Guardar">Guardar registro</button>
            <button class="boton secundario" type="reset">Restablecer valores</button>
            <a class="boton secundario" href="<?php echo e(route('categorias.index')); ?>">Cancelar</a>
            <?php if($registro->exists): ?>
                <button class="boton peligro" type="submit" name="accion" value="Eliminar" formnovalidate data-confirmar="¿Deseas eliminar este registro?">Eliminar registro</button>
            <?php endif; ?>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/categorias/form.blade.php ENDPATH**/ ?>