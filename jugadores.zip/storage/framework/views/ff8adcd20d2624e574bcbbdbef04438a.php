<?php $__env->startSection('titulo', 'Usuarios'); ?>
<?php $__env->startSection('accion'); ?>
    <a class="boton" href="<?php echo e(route('usuario.form')); ?>">+ Agregar usuario</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<section class="tarjeta listado">
    <div class="tabla-contenedor">
        <table>
            <caption>Listado de usuarios</caption>
            <thead>
                <tr>
                    <th scope="col">Nombre</th>
                    <th scope="col">Correo electrónico</th>
                    <th scope="col">Rol</th>
                    <th scope="col">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($registro->name); ?></td>
                        <td><?php echo e($registro->email); ?></td>
                        <td>
                            <?php if($registro->rol != null): ?>
                                <?php echo e($registro->rol->nombre); ?>

                            <?php else: ?>
                                Sin rol
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="acciones-tabla">
                                <a class="boton secundario pequeno" href="<?php echo e(route('usuario.form', $registro->id)); ?>">Editar</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="vacio" colspan="4">No hay registros. Usa el botón Agregar usuario para comenzar.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="paginacion">Total: <?php echo e($registros->count()); ?> registros.</p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/usuario/index.blade.php ENDPATH**/ ?>