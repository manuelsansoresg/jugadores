<?php $__env->startSection('titulo', $registro->exists ? 'Editar participante' : 'Agregar participante'); ?>
<?php $__env->startSection('contenido'); ?>

<section class="tarjeta formulario">
    <form method="POST" action="<?php echo e(route('partidaxusuario.save', $registro->id)); ?>" enctype="multipart/form-data">
        
        <?php echo csrf_field(); ?>
        <div class="campo">
            
            <label for="idpartida">Partida</label>
            <select id="idpartida" name="idpartida" required>
                <option value="">Selecciona una opción</option>
                <?php $__currentLoopData = $partidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partida): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($partida->id); ?>" <?php if(old('idpartida', $registro->idpartida) == $partida->id): echo 'selected'; endif; ?>><?php echo e($partida->clave); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="campo">
            <label for="idusuario">Usuario</label>
            <select id="idusuario" name="idusuario" required>
                <option value="">Selecciona una opción</option>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($usuario->id); ?>" <?php if(old('idusuario', $registro->idusuario) == $usuario->id): echo 'selected'; endif; ?>><?php echo e($usuario->name); ?> · <?php echo e($usuario->email); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        
        <div class="acciones-formulario">
            <button class="boton" type="submit" name="accion" value="Guardar">Guardar registro</button>
            <button class="boton secundario" type="reset">Restablecer valores</button>
            <a class="boton secundario" href="<?php echo e(route('partidaxusuario.index')); ?>">Cancelar</a>
            <?php if($registro->exists): ?>
                <button class="boton peligro" type="submit" name="accion" value="Eliminar" formnovalidate data-confirmar="¿Deseas eliminar este registro?">Eliminar registro</button>
            <?php endif; ?>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/partidaxusuario/form.blade.php ENDPATH**/ ?>