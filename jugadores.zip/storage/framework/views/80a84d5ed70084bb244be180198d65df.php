<?php $__env->startSection('titulo', $registro->exists ? 'Editar permiso' : 'Agregar permiso'); ?>
<?php $__env->startSection('contenido'); ?>
<section class="tarjeta formulario">
    <h2>Datos del permiso</h2>
    <p class="texto-suave">Completa los datos y guarda el registro.</p>

    <!-- Formulario para agregar o editar el registro. -->
    <form method="POST" action="<?php echo e(route('permiso.save', $registro->id)); ?>">
        <?php echo csrf_field(); ?>
        <div class="campo">
            <label for="nombre">Nombre</label>
            <input type="text" id="nombre" name="nombre" value="<?php echo e(old('nombre', $registro->nombre)); ?>" required maxlength="100">
            <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="error"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="campo">
            <label for="clave">Clave</label>
            <input type="text" id="clave" name="clave" value="<?php echo e(old('clave', $registro->clave)); ?>" required maxlength="100" pattern="[a-z_]+" <?php if($registro->exists): ?> readonly <?php endif; ?>>
            <small>Usa letras minúsculas y guion bajo. La clave guardada se conserva porque identifica el permiso en las rutas.</small>
            <?php $__errorArgs = ['clave'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="error"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="acciones-formulario">
            <button class="boton" type="submit" name="accion" value="Guardar">Guardar registro</button>
            <button class="boton secundario" type="reset">Restablecer valores</button>
            <a class="boton secundario" href="<?php echo e(route('permiso.index')); ?>">Cancelar</a>
            <?php if($registro->exists): ?>
                <button class="boton peligro" type="submit" name="accion" value="Eliminar" formnovalidate data-confirmar="¿Deseas eliminar este registro?">Eliminar registro</button>
            <?php endif; ?>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/permiso/form.blade.php ENDPATH**/ ?>