<?php $__env->startSection('titulo', 'Autores'); ?>
<?php $__env->startSection('accion'); ?>
    <a class="boton" href="<?php echo e(route('autores.form')); ?>">+ Agregar autor</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

<section class="tarjeta listado">
    <div class="tabla-contenedor">
        <table>
            <caption>Listado de autores</caption>
            <thead><tr><th scope="col">Nombre</th><th scope="col">Foto</th><th scope="col">Acciones</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($registro->nombre); ?></td><td><?php if($registro->foto): ?><img class="foto-catalogo" src="<?php echo e(asset($registro->foto)); ?>" alt="Foto de <?php echo e($registro->nombre); ?>" loading="lazy"><?php else: ?> Sin foto <?php endif; ?></td>
                        <td><a class="boton secundario pequeno" href="<?php echo e(route('autores.form', $registro->id)); ?>">Editar</a></td>
                    </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td class="vacio" colspan="3">No hay registros. Usa el botón Agregar autor para comenzar.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="paginacion">Total: <?php echo e($registros->count()); ?> registros.</p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/autores/index.blade.php ENDPATH**/ ?>