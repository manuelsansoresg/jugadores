<?php $__env->startSection('titulo', 'Permisos'); ?>
<?php $__env->startSection('accion'); ?>
    <a class="boton" href="<?php echo e(route('permiso.form')); ?>">+ Agregar permiso</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<section class="tarjeta listado">
    <div class="tabla-contenedor">
        <table>
            <caption>Listado de permisos</caption>
            <thead>
                <tr>
                    <th scope="col">Nombre</th>
                    <th scope="col">Clave</th>
                    <th scope="col">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($registro->nombre); ?></td>
                        <td><?php echo e($registro->clave); ?></td>
                        <td>
                            <div class="acciones-tabla">
                                <a class="boton secundario pequeno" href="<?php echo e(route('permiso.form', $registro->id)); ?>">Editar</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="vacio" colspan="3">No hay registros. Usa el botón Agregar permiso para comenzar.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="paginacion">Total: <?php echo e($registros->count()); ?> registros.</p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/permiso/index.blade.php ENDPATH**/ ?>