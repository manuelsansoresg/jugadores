<?php $__env->startSection('titulo', 'Acceso denegado'); ?>
<?php $__env->startSection('contenido'); ?>
<section class="tarjeta formulario perfil"><span class="material-symbols-outlined perfil-icono error">shield_lock</span><p class="etiqueta">ERROR 403</p><h1>Acceso denegado</h1><p class="texto-suave">Tu rol no tiene permiso para entrar a esta página.</p><a class="boton" href="<?php echo e(route('inicio')); ?>">Volver al inicio</a></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/errors/403.blade.php ENDPATH**/ ?>