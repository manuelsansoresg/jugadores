<?php $__env->startSection('titulo', 'Iniciar sesión'); ?>
<?php $__env->startSection('contenido'); ?>
<div class="tarjeta-acceso">
    <div class="presentacion"><img src="<?php echo e(asset('plantilla/logo2.svg')); ?>" alt="Subas Art"><p>Bienvenido a Subas Art</p><span>Entra con tu cuenta para continuar.</span></div>
    <section class="formulario-acceso">
        <p class="etiqueta">SUBAS ART</p><h1>Iniciar sesión</h1><p class="texto-suave">Ingresa tu correo y tu contraseña.</p>
        <form method="POST" action="<?php echo e(route('login.entrar')); ?>">
            <?php echo csrf_field(); ?>
        <div class="campo">
            <label for="email">Correo electrónico</label>
            <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="username" autofocus>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="error"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="campo">
            <label for="password">Contraseña</label>
            <input type="password" id="password" name="password" required autocomplete="current-password">
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="error"><?php echo e($message); ?></small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
            <button class="boton ancho" type="submit">Iniciar sesión <span class="material-symbols-outlined">arrow_forward</span></button>
        </form>
        <div class="separador">¿No tienes una cuenta?</div>
        <a class="boton secundario ancho" href="<?php echo e(route('registro')); ?>">Crear una cuenta</a>
        <p class="pie">Subas Art · 2026</p>
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/login.blade.php ENDPATH**/ ?>