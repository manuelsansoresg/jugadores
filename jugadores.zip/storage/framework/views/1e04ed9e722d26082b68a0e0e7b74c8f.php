<?php $__env->startSection('titulo', 'Roles'); ?>
<?php $__env->startSection('accion'); ?>
    <a class="boton" href="<?php echo e(route('rol.form')); ?>">+ Agregar rol</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>
<section class="tarjeta listado">
    <div class="tabla-contenedor">
        <table>
            <caption>Listado de roles</caption>
            <thead>
                <tr>
                    <th scope="col">Nombre</th>
                    <th scope="col">Permisos asignados</th>
                    <th scope="col">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($registro->nombre); ?></td>
                        <td>
                            <?php $__empty_2 = true; $__currentLoopData = $registro->permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                <span><?php echo e($permiso->nombre); ?></span><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                Sin permisos
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="acciones-tabla">
                                <a class="boton secundario pequeno" href="<?php echo e(route('rol.form', $registro->id)); ?>">Editar</a>
                                <a class="boton secundario pequeno" href="<?php echo e(route('rol.permisos', $registro->id)); ?>">Permisos</a>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="vacio" colspan="3">No hay registros. Usa el botón Agregar rol para comenzar.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="paginacion">Total: <?php echo e($registros->count()); ?> registros.</p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/rol/index.blade.php ENDPATH**/ ?>