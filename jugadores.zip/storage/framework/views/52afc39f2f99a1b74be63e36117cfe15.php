<?php $__env->startSection('titulo', 'Categorías'); ?>
<?php $__env->startSection('accion'); ?>
    <a class="boton" href="<?php echo e(route('categorias.form')); ?>">+ Agregar categoría</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('contenido'); ?>

<section class="tarjeta listado">
    <div class="tabla-contenedor">
        <table>
            <caption>Listado de categorías</caption>
            <thead><tr><th scope="col">Nombre</th><th scope="col">Acciones</th></tr></thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $registros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($registro->nombre); ?></td>
                        <td><a class="boton secundario pequeno" href="<?php echo e(route('categorias.form', $registro->id)); ?>">Editar</a></td>
                    </tr>
                
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td class="vacio" colspan="2">No hay registros. Usa el botón Agregar categoría para comenzar.</td></tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <p class="paginacion">Total: <?php echo e($registros->count()); ?> registros.</p>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/categorias/index.blade.php ENDPATH**/ ?>