<?php $__env->startSection('titulo', $registro->exists ? 'Editar partida' : 'Agregar partida'); ?>
<?php $__env->startSection('contenido'); ?>

<section class="tarjeta formulario">
    <form method="POST" action="<?php echo e(route('partidas.save', $registro->id)); ?>" enctype="multipart/form-data">
        
        <?php echo csrf_field(); ?>
        <div class="campo">
            <label for="clave">Clave</label>
            <input id="clave" name="clave" value="<?php echo e(old('clave', $registro->clave)); ?>" maxlength="10" required>
        </div>
        <div class="campo">
            <label for="status">Estado</label>
            <input type="number" step="1" id="status" name="status" value="<?php echo e(old('status', $registro->status)); ?>" required>
        </div>
        <?php if($registro->exists): ?>
            <p>Fecha de creación: <?php echo e($registro->fecha_creacion->format('d/m/Y H:i')); ?></p>
        <?php endif; ?>
        
        <div class="acciones-formulario">
            <button class="boton" type="submit" name="accion" value="Guardar">Guardar registro</button>
            <button class="boton secundario" type="reset">Restablecer valores</button>
            <a class="boton secundario" href="<?php echo e(route('partidas.index')); ?>">Cancelar</a>
            <?php if($registro->exists): ?>
                <button class="boton peligro" type="submit" name="accion" value="Eliminar" formnovalidate data-confirmar="¿Deseas eliminar este registro?">Eliminar registro</button>
            <?php endif; ?>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/partidas/form.blade.php ENDPATH**/ ?>