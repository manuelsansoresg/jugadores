<?php $__env->startSection('titulo', $registro->exists ? 'Editar obra' : 'Agregar obra'); ?>
<?php $__env->startSection('contenido'); ?>

<section class="tarjeta formulario">
    <form method="POST" action="<?php echo e(route('obras.save', $registro->id)); ?>" enctype="multipart/form-data">
        
        <?php echo csrf_field(); ?>
        <div class="campo">
            <label for="nombre">Nombre</label>
            <input id="nombre" name="nombre" value="<?php echo e(old('nombre', $registro->nombre)); ?>" maxlength="100" required>
        </div>
        <div class="campo">
            
            <label for="idautor">Autor</label>
            <select id="idautor" name="idautor" required>
                <option value="">Selecciona una opción</option>
                <?php $__currentLoopData = $autores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $autor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($autor->id); ?>" <?php if(old('idautor', $registro->idautor) == $autor->id): echo 'selected'; endif; ?>><?php echo e($autor->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="campo">
            <label for="idcategoria">Categoría</label>
            <select id="idcategoria" name="idcategoria" required>
                <option value="">Selecciona una opción</option>
                <?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($categoria->id); ?>" <?php if(old('idcategoria', $registro->idcategoria) == $categoria->id): echo 'selected'; endif; ?>><?php echo e($categoria->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="campo">
            <label for="foto">Foto</label>
            
            <?php if($registro->foto): ?>
                <img class="foto-catalogo" src="<?php echo e(asset($registro->foto)); ?>" alt="Foto actual de <?php echo e($registro->nombre); ?>">
            <?php endif; ?>
            <input type="file" id="foto" name="foto" accept="image/jpeg,image/png,image/gif,image/webp">
            <small>Opcional. JPG, PNG, GIF o WebP de hasta 2 MB. Al editar, déjala vacía para conservar la foto actual.</small>
        </div>
        
        <div class="acciones-formulario">
            <button class="boton" type="submit" name="accion" value="Guardar">Guardar registro</button>
            <button class="boton secundario" type="reset">Restablecer valores</button>
            <a class="boton secundario" href="<?php echo e(route('obras.index')); ?>">Cancelar</a>
            <?php if($registro->exists): ?>
                <button class="boton peligro" type="submit" name="accion" value="Eliminar" formnovalidate data-confirmar="¿Deseas eliminar este registro?">Eliminar registro</button>
            <?php endif; ?>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/obras/form.blade.php ENDPATH**/ ?>