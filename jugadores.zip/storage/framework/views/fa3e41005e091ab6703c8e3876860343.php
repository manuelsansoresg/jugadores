<?php $__env->startSection('titulo', 'Permisos del rol: '.$rol->nombre); ?>
<?php $__env->startSection('contenido'); ?>
<section class="tarjeta formulario">
    <h2>Asignación de permisos</h2>
    <p class="texto-suave">Marca los accesos que tendrá el rol <?php echo e($rol->nombre); ?>.</p>

    <!-- Solo se envían los permisos que estén marcados. -->
    <form method="POST" action="<?php echo e(route('rol.asignar', $rol->id)); ?>">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <label class="casilla">
                <input type="checkbox" name="idpermiso[]" value="<?php echo e($permiso->id); ?>" <?php if(in_array($permiso->id, old('idpermiso', $asignados))): ?> checked <?php endif; ?>>
                <span><?php echo e($permiso->nombre); ?></span>
            </label>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="acciones-formulario">
            <button class="boton" type="submit">Guardar permisos</button>
            <a class="boton secundario" href="<?php echo e(route('rol.index')); ?>">Volver a roles</a>
        </div>
    </form>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/rol/permisos.blade.php ENDPATH**/ ?>