<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo $__env->yieldContent('titulo', 'Inicio'); ?> | Subas Art</title>
    <link rel="stylesheet" href="<?php echo e(asset('plantilla/fonts/fonts.css')); ?>">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="<?php if(auth()->guard()->check()): ?> sistema <?php else: ?> acceso <?php endif; ?>">
    
    <?php if(auth()->guard()->check()): ?>
        <aside class="menu" id="menu">
            <a class="marca" href="<?php echo e(route('inicio')); ?>"><span class="material-symbols-outlined marca-icono">token</span> SUBAS ART</a>
            <p class="etiqueta">MENÚ PRINCIPAL</p>
            <nav aria-label="Menú principal">
                <a class="<?php echo e(request()->routeIs('inicio') ? 'activo' : ''); ?>" href="<?php echo e(route('inicio')); ?>"><span class="material-symbols-outlined">home</span> Inicio</a>
                
                <?php if(tiene_permiso('administrar_usuario')): ?>
                    <a class="<?php echo e(request()->routeIs('usuario.*') ? 'activo' : ''); ?>" href="<?php echo e(route('usuario.index')); ?>"><span class="material-symbols-outlined">group</span> Usuarios</a>
                <?php endif; ?>
                <?php if(tiene_permiso('administrar_permiso')): ?>
                    <a class="<?php echo e(request()->routeIs('permiso.*') ? 'activo' : ''); ?>" href="<?php echo e(route('permiso.index')); ?>"><span class="material-symbols-outlined">verified_user</span> Permisos</a>
                <?php endif; ?>
                <?php if(tiene_permiso('administrar_rol')): ?>
                    <a class="<?php echo e(request()->routeIs('rol.*') ? 'activo' : ''); ?>" href="<?php echo e(route('rol.index')); ?>"><span class="material-symbols-outlined">manage_accounts</span> Roles</a>
                <?php endif; ?>
                <?php if(tiene_permiso('administrar_obra')): ?>
                    <a class="<?php echo e(request()->routeIs('obras.*') ? 'activo' : ''); ?>" href="<?php echo e(route('obras.index')); ?>"><span class="material-symbols-outlined">palette</span> Obras</a>
                <?php endif; ?>
                <?php if(tiene_permiso('administrar_autor')): ?>
                    <a class="<?php echo e(request()->routeIs('autores.*') ? 'activo' : ''); ?>" href="<?php echo e(route('autores.index')); ?>"><span class="material-symbols-outlined">person_edit</span> Autores</a>
                <?php endif; ?>
                <?php if(tiene_permiso('administrar_categoria')): ?>
                    <a class="<?php echo e(request()->routeIs('categorias.*') ? 'activo' : ''); ?>" href="<?php echo e(route('categorias.index')); ?>"><span class="material-symbols-outlined">category</span> Categorías</a>
                <?php endif; ?>
                <?php if(tiene_permiso('administrar_partidaxusuario')): ?>
                    <a class="<?php echo e(request()->routeIs('partidaxusuario.*') ? 'activo' : ''); ?>" href="<?php echo e(route('partidaxusuario.index')); ?>"><span class="material-symbols-outlined">groups</span> Participantes</a>
                <?php endif; ?>
                <?php if(tiene_permiso('administrar_partida')): ?>
                    <a class="<?php echo e(request()->routeIs('partidas.*') ? 'activo' : ''); ?>" href="<?php echo e(route('partidas.index')); ?>"><span class="material-symbols-outlined">sports_esports</span> Partidas</a>
                <?php endif; ?>
            </nav>
            <div class="menu-pie">Subas Art · Proyecto escolar</div>
        </aside>
        <header class="barra">
            <button class="boton secundario abrir-menu" id="abrir-menu" type="button" aria-controls="menu" aria-expanded="false" aria-label="Abrir menú"><span class="material-symbols-outlined">menu</span></button>
            <div class="cuenta"><strong><?php echo e(auth()->user()->name); ?></strong><span><?php echo e(auth()->user()->email); ?></span></div>
            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button class="boton secundario" type="submit"><span class="material-symbols-outlined">logout</span> Cerrar sesión</button></form>
        </header>
    <?php endif; ?>

    <main class="principal">
        <?php if(auth()->guard()->check()): ?>
            <div class="cabecera"><div><p class="etiqueta">SUBAS ART</p><h1><?php echo $__env->yieldContent('titulo', 'Inicio'); ?></h1></div><?php echo $__env->yieldContent('accion'); ?></div>
        <?php endif; ?>
        <div class="contenido">
            <?php if(session('mensaje')): ?><div class="aviso" role="status"><?php echo e(session('mensaje')); ?></div><?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="errores" role="alert"><strong>Revisa estos datos:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div>
            <?php endif; ?>
            <?php echo $__env->yieldContent('contenido'); ?>
        </div>
    </main>
</body>
</html>
<?php /**PATH /Users/manuel/Documents/proyectos/web/jugadores/resources/views/layouts/master.blade.php ENDPATH**/ ?>